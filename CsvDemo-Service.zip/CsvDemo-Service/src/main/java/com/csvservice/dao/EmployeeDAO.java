package com.csvservice.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.csvservice.model.Employee;
import com.csvservice.repository.EmployeeRepository;
@Repository
public class EmployeeDAO {
	
	@Autowired
	private EmployeeRepository employeeRepository;

	public void batchStore(List<Employee> studentList) {
		employeeRepository.saveAll(studentList);
	}

	public List<Employee> getEmployees() {
		return (List<Employee>) employeeRepository.findAll();
	}


}
