package com.csvservice.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.csvservice.model.Employee;
import com.csvservice.service.UploadCSVService;

@RestController
@RequestMapping("/employees,")
public class UploadCSVController {
	
	@Autowired
	private UploadCSVService uploadCsvService;

	@Autowired
	UploadCSVController(UploadCSVService uploadCsvService) {
		this.uploadCsvService = uploadCsvService;
	}

	@RequestMapping(value = "/upload", method = RequestMethod.POST)
	public List<Employee> uploadFile(@RequestPart(value = "file") MultipartFile multiPartFile) throws IOException {
		return uploadCsvService.uploadFile(multiPartFile);
	}
	
	@RequestMapping
	public List<Employee> getStudents(){
		return uploadCsvService.getEmployees();
	}
	
	
	

}
